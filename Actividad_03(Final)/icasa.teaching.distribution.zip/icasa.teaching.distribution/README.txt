iCasa-Simulator distribution
====================

This is a distribution of iCasa-Simulator.
You can find more information about the execution platform including source code on the iCasa-Platform website (https://github.com/AdeleResearchGroup/iCasa-Platform).

iCasa-Platform is licensed under Apache V2 license.
iCasa-Simulator is licensed under a specific end user license (http://adeleresearchgroup.github.com/iCasa-Simulator/snapshot/license.html).

To launch the gateway part, execute startGateway.bat on Windows or startGateway.sh file on Unix systems depending on your operating system.
To launch the web server part, execute startGUI.bat on Windows or startGUI.sh file on Unix systems depending on your operating system.

Use iCasa-Simulator
====================

Recommended browser:
- Firefox

Supported browsers:
- Firefox
- Chrome

Open a web browser on url http://localhost:9000/ to get home simulator screen.
